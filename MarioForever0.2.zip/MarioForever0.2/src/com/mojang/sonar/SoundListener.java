package com.mojang.sonar;

public interface SoundListener extends SoundSource
{
}