package com.mojang.sonar;

public interface SoundSource
{
	public float getX(float alpha);
	public float getY(float alpha);
}